import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class end here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */


public class End extends World
{
    GreenfootSound background= new GreenfootSound("WinningSound.wav");
    /**
     * Constructor for objects of class end.
     * 
     */
    public End()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 600, 1); 
        addObject(new pressQ(), 300, 300);
        background.play();
    }
}
