import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class counter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class counter extends Actor
{
    int score = 80;
    /**
     * Act - do whatever the counter wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setImage(new GreenfootImage("score : "+ score, 24, Color.GREEN, Color.BLACK));// Add your action code here.
    }    
    
    public void updateScore (int score)
    {
        this.score += score;
    }
    
        public int getScore ()
    {
        return this.score;
    }
}
