import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pressQ here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pressQ extends Actor
{
    /**
     * Act - do whatever the pressS wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    //GreenfootImage myImage;
    public void act() 
    {
        if (Greenfoot.isKeyDown("r"))
        {
            Greenfoot.setWorld(new Intro());
        }// Restart the game again.
        
        if (Greenfoot.isKeyDown("q"))
        {
            System.exit(0);
        }// Restart the game again.
    }  
    
    public pressQ()
    {
        //myImage = new GreenfootImage("intro.png");
        getImage().scale(400,180);
    }
}

