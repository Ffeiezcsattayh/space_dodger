import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1 extends World
{
    counter counter = new counter();
    /**
     * Constructor for objects of class Level1.
     * 
     */
    
    GreenfootSound background= new GreenfootSound("rocket.wav");
    public Level1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        
        for (int i=0; i<3; i++) addObject(new enemy1(), 150+i*60, 180);        
        for (int i=0; i<4; i++) addObject(new enemy1(), 220+i*80, 300);

        addObject(new gamer1(), 400, 400);
        addObject(new safeHouse(), 300, 50);
        addObject(counter, 100, 40);
        
        background.play();
    }
    
    public counter getCounter()
    {
        return counter;
    }
}
