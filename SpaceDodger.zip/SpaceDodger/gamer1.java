import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class gamer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class gamer1 extends Actor
{
    private int score = 100; 
    
    private GreenfootImage left;
    private GreenfootImage right;
    private GreenfootImage up;
    /**
     * Act - do whatever the gamer wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        // get the counter
        World myWorld = getWorld();
        Level1 mySpace = (Level1)myWorld;
        counter myCounter = mySpace.getCounter();
        
        // check the key strokes and update the score
        if ( Greenfoot.isKeyDown("left") )
        {
            setImage(left);
            move(-50);
            myCounter.updateScore(-5); // each operation costs 5 points;
        }
        if ( Greenfoot.isKeyDown("right") )
        {
            setImage(right);
            move(50);
            myCounter.updateScore(-5); // each operation costs 5 points;
        }
        if ( Greenfoot.isKeyDown("up") )
        {   
            setImage(up);
            setLocation(getX(), getY() - 50); 
            myCounter.updateScore(-5); // each operation costs 5 points;
        }

        if ( Greenfoot.isKeyDown("down") )
        {   setLocation(getX(), getY() + 50); 
            myCounter.updateScore(-5); // each operation costs 5 points;
        }
        
        // Check collision 
        if(isTouching(enemy1.class))
        {
            myCounter.updateScore(-30);
            setLocation(400, 700);
            Greenfoot.playSound("Explosion.wav");
            //if (myCounter.getScore() < 0 ) { // if it collides with the enermies or is too slow 
            //    Greenfoot.setWorld(new LostScreen1());
            //}
        } 
        
        // Check the destination
        if(isTouching(safeHouse.class))
        {
            myCounter.updateScore(1000);
            Greenfoot.delay(50);
            Greenfoot.setWorld(new WinScreen1());        
        }
        
    
        if (myCounter.getScore() < 0 ) { // if it collides with the enermies or is too slow 
            Greenfoot.setWorld(new LostScreen1());
        }
    }
    
    public gamer1()
    {
        //getImage().scale(40,60);
        left = new GreenfootImage("rocket_left.png");
        left.scale(60,40);
        right = new GreenfootImage("rocket_right.png");
        right.scale(60,40);
        up = new GreenfootImage("rocket_up.png");
        up.scale(40,60);
        setImage(up);
    }

}
