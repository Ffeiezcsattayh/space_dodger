import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class enemy3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemy3 extends Actor
{
    private int time=100;
    /**
     * Act - do whatever the enemy3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        turn(30);
        setLocation((getX()+5)%600, (getY()+5)%400);
        Greenfoot.delay(5);// Add your action code here.        // Add your action code here.
    }    
    
    public enemy3()
    {
        getImage().scale(40,40);
    }
    
}
