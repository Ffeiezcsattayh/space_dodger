import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Impossible games.
 * 
 * @author Vivian Wang
 * 
 * @version 1.1
 */
public class Intro extends World
{
    public Intro() 
    {
        super(600,600,1);
        addObject(new pressS(), 300, 300);
        //Explosion.initialiseImages();
    }
}