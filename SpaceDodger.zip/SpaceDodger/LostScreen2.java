import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LostSence2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LostScreen2 extends World
{

    /**
     * Constructor for objects of class LostSence2.
     * 
     */

    textBox1 text= new textBox1();
    textBox2 text2= new textBox2();
    textBox3 text3= new textBox3();
    GreenfootSound background= new GreenfootSound("LosingSound.wav");
    //constructor
    public LostScreen2()
    {    
        super(600, 600, 1); 
         // Create a new world with 800 x 800 cells with a cell size of 1x1 pixels.
        
        addObject(text,300, 300);
        
        addObject(text2,200, 500);
        
        addObject(text3 ,400, 500);
        //creates scene
        
        showText("You Lost!", 300, 300);
        
        showText("Try again?", 200, 500);
        
        showText("Quit?", 400, 500);
        //indicates which text box does what
        
        background.play();
        //music
       
    }
    
    public void act()
    {
       
         if( Greenfoot.mouseClicked(text2))
        {
            Level2 game = new Level2();
            Greenfoot.setWorld(game);
        }
        //restarts game if person wants to try again
        
        if(Greenfoot.mouseClicked(text3))
        {
            Intro game = new Intro();
            Greenfoot.setWorld(game);
        }
        // goes back to demo screen if person wants to quit
    }


}

