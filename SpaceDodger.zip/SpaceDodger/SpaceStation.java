import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class enemy2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SpaceStation extends Actor
{
    /**
     * Act - do whatever the SpaceStation wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // space station rotates around
        setLocation((getX()+10)%600, (getY()+10)%200);
        Greenfoot.delay(15);// Add your action code here.// Add your action code here.
    }    
    
    public SpaceStation()
    {
        getImage().scale(60,60);
    }
}
