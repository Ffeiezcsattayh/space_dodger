import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pressS here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pressS extends Actor
{
    /**
     * Act - do whatever the pressS wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    //GreenfootImage myImage;
    public void act() 
    {
        if (Greenfoot.isKeyDown("s"))
        {
            Greenfoot.setWorld(new Level1());
        }// start game at level 1.
        
        if (Greenfoot.isKeyDown("2"))
        {
            Greenfoot.setWorld(new Level2());
        }// start the game at level 2.
    }  
    
    public pressS()
    {
        getImage().scale(450,350);
    }
}
