import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class gamer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class gamer2 extends Actor
{
    private GreenfootImage left;
    private GreenfootImage right;
    private GreenfootImage up;
    /**
     * Act - do whatever the gamer wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
       
        // get myworld and mycounter
        World myWorld = getWorld();
        Level2 mySpace = (Level2)myWorld;
        counter myCounter = mySpace.getCounter();
        SpaceStation myStation = mySpace.getStation();
        
        // check the keystrokes and update the score
        if ( Greenfoot.isKeyDown("left") )
        {
            setImage(left);
            move(-50);
            myCounter.updateScore(-5); // each operation costs 5 points;
        }
        if ( Greenfoot.isKeyDown("right") )
        {
            setImage(right);
            move(30);
            myCounter.updateScore(-5); // each operation costs 5 points;
        }
        if ( Greenfoot.isKeyDown("up") )
        {   setImage(up);
            setLocation(getX(), getY() - 30); 
            myCounter.updateScore(-5); // each operation costs 5 points;
        }

        if ( Greenfoot.isKeyDown("down") )
        {   setImage(up);
            setLocation(getX(), getY() + 30); 
            myCounter.updateScore(-5); // each operation costs 5 points;
        }
        
        if ( Greenfoot.isKeyDown("space") )
        {  setImage(up);
           setLocation(getX(), getY() - 70); 
           myCounter.updateScore(-15); // each operation costs 15 points;            
        }
        
        // Check collision 
        if(isTouching(enemy1.class) || isTouching(enemy3.class))
        {
            myCounter.updateScore(-30);
            setLocation(400, 700);
            Greenfoot.playSound("Explosion.wav");
            if (myCounter.getScore() < 0 ) { // if it collides with the enermies or is too slow 
                Greenfoot.setWorld(new LostScreen2());
            }
        }
       
        // check friend
        if(isTouching(SpaceStation.class))
        {
            // add 50 points to the score board
            myCounter.updateScore(50);
            
            // add extra 15 second to the game time
            mySpace.updateTime(15);
            
            // remove the friend from my space
            mySpace.removeObject(myStation);
            Greenfoot.playSound("spacestation.wav");
        } 
        // Check the destination
        
        if(isTouching(safeHouse.class))
        {
            // game finished
            Greenfoot.setWorld(new End());
            
        }
        
    } 
    
    public gamer2()  // constructor
    {
        // set up images
        left = new GreenfootImage("rocket_left.png");
        left.scale(60,40);
        right = new GreenfootImage("rocket_right.png");
        right.scale(60,40);
        up = new GreenfootImage("rocket_up.png");
        up.scale(40,60);
        setImage(up);
    }
}
