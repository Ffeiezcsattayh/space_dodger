import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level2 extends World
{
    public int time=100;
    counter counter = new counter();
    SpaceStation myStation = new SpaceStation();
    /**
     * Constructor for objects of class Level2.
     * 
     */
    
    safeHouse myHouse = new safeHouse();
    GreenfootSound background= new GreenfootSound("rocket.wav");
    public Level2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        for (int i=0; i<3; i++) addObject(new enemy1(), Greenfoot.getRandomNumber(600), 300);  
        for (int i=0; i<2; i++) addObject(new enemy3(), Greenfoot.getRandomNumber(300), 200);    
        
        addObject(myStation, Greenfoot.getRandomNumber(400), 200);
        addObject(new gamer2(), 400, 700);    
        addObject(myHouse, 300, 50);
        addObject(counter, 100, 40);
        background.play();
    }
    
    public void act()
    {
        showTime();
        decrementTime();
        if (time % 25 == 0) {
           removeObject(myHouse);
           myHouse = new safeHouse();
           addObject(myHouse, 200 + Greenfoot.getRandomNumber(100), 100 + Greenfoot.getRandomNumber(100));
        }
    }
    
        private void showTime()
    {
        showText("Time: " + time, 475, 25); 
    }
    
    private void decrementTime()
    {
        time--;
        Greenfoot.delay(1);
        showTime();
        if (time == 0)
        {
            LostScreen2 lose= new LostScreen2();
            Greenfoot.setWorld(lose);
        }
        
    }
    
    public counter getCounter()
    {
        return counter;
    }
    
    public SpaceStation getStation()
    {
        return myStation;
    }
    
    public void updateTime(int bonus)
    {
        time += bonus;
    }
}
