import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemy1 extends Actor
{
    /**
     * Act - do whatever the enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (getY() < 200) {
        
        setLocation((getX()+20)%600, getY()); // set location
        turn(45); // add the spin 
        Greenfoot.delay(10);
        }
        
        
        if (getY() > 200) {
        
           setLocation((getX()-40)%600, getY()); // set location
           turn(-45); // add the spin
        
           if(getX() <= 0)
           {
               setLocation(800, 300); 
               setLocation(getX()-40, getY());
               //turn(90);
            // Add your action code here.
           }
        Greenfoot.delay(5);// Add your action code here.
        }
    }  
    
    public enemy1()
    {
        getImage().scale(60,60);
    }
    
}
